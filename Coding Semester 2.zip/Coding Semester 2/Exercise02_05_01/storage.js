//BY:George Rautio
//FILE NAME: storage.js
//DATE CREATED: February 23, 2018
//ABOUT: Handles all database connections and stored data

var MongoClient = require('mongodb').MongoClient;
var ObjectID =require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017';
var dbName = 'twitter-notes';
var database;
module.exports = {
//handle the database connections
    connect: function(){//connects to the databse and tells info about it
        MongoClient.connect(url, function(err, client){
            if (err){
                return console.log('Error: ' + err);
            }
            database = client.db(dbName);
            console.log('Connected to database: ' + dbName);
        });
    },
    
    connected: function(){
        return typeof database != 'undefined';
    },
    
    insertFriends: function(friends) {
        database.collection('friends').insert(friends, function(err){
            if(err){//debug to tell if we cant input friends 
                console.log('cannot insert friends into database');
            }
        });
    },
    getFriends: function(userId, callback){
        var cursor = database.collection("friends").find({for_user: userId});
        cursor.toArray(callback);
        
    },
    deleteFriends: function(){
        database.collection("friends").remove(({}), function(err){
            if(err){
                console.log('Cannot remove friends from database.')
            }
        });
    },
    getNotes: function(ownerid, friendid, callback){//Gets the note form the collection and maps it and puts into the array
        var cursor = database.collection('notes').find({
            owner_id: ownerid,
            friend_id: friendid
        });
        cursor.toArray(function(err, notes){
            if(err){
                return callback(err);
            }
            callback(null, notes.map(function(note){
                return {
                    _id: note._id,
                    content: note.content
                }
            }));
        });
    },
        insertNote: function(ownerid, friendid, content, callback){//inserts the note into the database notes collection
            database.collection('notes').insert({
                owner_id: ownerid,
                friend_id: friendid,
                content: content
            }, function(err, result){
                if(err){
                    return callback(err, result);
                }
                callback(null, {
                    _id: result.ops[0]._id,
                    content: result.ops[0].content
                });
            });
        },
    updateNote: function(noteid, ownerid, content, callback){//updates the selected note content in the database collection
        database.collection('notes').updateOne({
        _id: new ObjectID(noteid),
        owner_id: ownerid
        },
        {
            $set: {content: content}
        },
    function(err, result){
            if(err){
                return callback(err);
            }
            database.collection('notes').findOne({
             _id: new ObjectID(noteid)
            },callback);
        });
    },
    deleteNote: function(noteId, ownerId, callback) {// Deletes the selected note content in the database collection
        database.collection('notes').deleteOne({
            _id: new ObjectID(noteId),
            owner_id: ownerId
        },callback);
    }
}
    
