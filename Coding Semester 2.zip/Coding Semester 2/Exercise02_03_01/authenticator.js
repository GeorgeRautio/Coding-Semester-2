//BY:George Rautio
//FILE NAME:authenticator.js
//DATE CREATED:January 23, 2018
//ABOUT:Authentication and authorization using oauth module to establish a link with twitter

var OAuth = require('OAuth').OAuth;
var config = require('./config.json');
var oauth = new OAuth(config.request_token_url,
                      config.access_token_url, 
                      config.consumer_key, 
                      config.consumer_secret,
                      config.oauth_version, 
                      config.oauth_callback, 
                      config.oauth_signature);

var twitterCredentials = {//stores our twitter Credentials in a JSON object
    oauth_token: "",
    oauth_token_secret: "",
    access_token: "",
    access_token_secret: "",
    twitter_id: ""

    
}

module.exports = {
//build a generic function Named get made to handle any twitters GET calls  
    get: function(url, access_token, oauth_access_token_secret, callback) {
        oauth.get.call(oauth, url, access_token, oauth_access_token_secret, callback);
    }, 
    post: function(url, access_token, oauth_access_token_secret, body, callback) {
        oauth.post.call(oauth, url, access_token, oauth_access_token_secret, body, callback);
    },
    getCredential: function(){
        return twitterCredentials;
    },
    clearCredentials: function(){
        twitterCredentials.oauth_token = "";
        twitterCredentials.oauth_token_secret = "";
        twitterCredentials.access_token = "";
        twitterCredentials.access_token_secret = "";
        twitterCredentials.twitter_id = "";
    },
// building a module and everything geting every thing that is avalible and required for us to use it
    redirectToTwitterLogginPage: function(req, res){
        oauth.getOAuthRequestToken(function(error, oauth_token, oauth_token_secret, results){
          if(error){
              console.log(error);
              res.send('authentication failed!');
          }
            else{
              twitterCredentials.oauth_token = oauth_token;
                twitterCredentials.oauth_token_secret = oauth_token_secret;
               res.redirect(config.authorization_url + '?oauth_token=' + oauth_token);
                
            }
        });
    }, 
 
    authenticate: function(req, res, callback) {// this is makeing sure that all three keys are present oauth_token,oauth_token_secret,oauth_verifier and if not it will throw an error
        if (!(twitterCredentials.oauth_token && twitterCredentials.oauth_token_secret && req.query.oauth_verifier)) {
            return callback('Request does not have all required keys.');
        }
        oauth.getOAuthAccessToken(twitterCredentials.oauth_token, twitterCredentials.oauth_token_secret, req.query.oauth_verifier,
        function(error, oauth_access_token, oauth_access_token_secret, results) {
            if (error) {
                return callback(error);
            }
            
            
//one of twitters apis that is used to verify our twitter Credentials and that everything is there if not it will error out or it will give our requested data
            var url = "https://api.twitter.com/1.1/account/verify_credentials.json";
            oauth.get(url, oauth_access_token, oauth_access_token_secret, function(error, data) {
                if (error) {
                    console.log(error);
                    return callback(error);
                }
                data = JSON.parse(data);
//                console.log(data);
                twitterCredentials.access_token = oauth_access_token;
                twitterCredentials.access_token_secret = oauth_access_token_secret;
                twitterCredentials.twitter_id = data.id_str;
                callback();
            });
        });
    }
}