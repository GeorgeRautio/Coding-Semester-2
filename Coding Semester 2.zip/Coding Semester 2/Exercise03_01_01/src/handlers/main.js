var popGen = require('../lib/popGen'),
    dataStore = require('../lib/dataStore'),
    mainContent = require('../generators/mainContent');

module.exports = function (request, reply) {
    const gen = mainContent();
    gen.next();
    popGen.getPopularSlices()
        .then((popSlices) => {
            gen.next(popSlices);
            return popGen.getMostPopular();
        })
        .then((mostPopular) => {
            gen.next(mostPopular);
            return popGen.getNewestSlice();
        })
        .then((newestSlice) => {
            gen.next(newestSlice);
            return popGen.getMostImproved();
        })
        .then((mostImproved) => {
            gen.next(mostImproved);
            return dataStore.getPizzas()
        })
        .then((pizzas) => {
            return reply.view('index', gen.next(pizzas).value);
        })


    //    var context = {};
    //    const promises = [
    //              popGen.getPopularSlices(),
    //              popGen.getMostPopular(),
    //              popGen.getNewestSlice(),
    //              popGen.getMostImproved(),
    //              dataStore.getPizzas()
    //    ];
    //
    //    Promise.all(promises)
    //        .then((results) => {
    //             context = {
    //                popSlices: results[0],
    //                mostPopular: results[1],
    //                newestSlice: results[2],
    //                mostImproved: results[3],
    //                pizzas: results[4]
    //            }
    //                return reply.view('index', context);
    //        })
    //        .catch((err) => {
    //            console.error(err);
    //        });
};
