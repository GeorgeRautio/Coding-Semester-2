module.exports = function (object) {
  return JSON.stringify(object);
};
