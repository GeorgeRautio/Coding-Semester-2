module.exports = function (value) {
  return Math.abs(value * 100).toFixed(2) + '%';
};
