module.exports = {
  method: 'GET',
  path: '/',
  handler: require('../handlers/main')
};
