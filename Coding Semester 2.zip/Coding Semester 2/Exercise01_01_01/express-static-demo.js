//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: express-static-demo.js
var express = require('express');//The global Object require is used to call in express
var app = express();

var port = 8080; //port var decleration

app.use(express.static(__dirname));

app.listen(port, function(){
    console.log('server is listening on localhost:%s', port);//console.log that says the port
});