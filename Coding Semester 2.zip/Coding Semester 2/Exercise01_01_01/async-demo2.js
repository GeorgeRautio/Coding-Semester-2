//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: async-demo2.js


var fs = require('fs');// var decleration for file system


fs.readdir('.', function(err, data) {//callback functtion not named
   console.log('data: ', data); //displays the data
});

console.log('This is the last code');//prints this is  the last code in the terminal

