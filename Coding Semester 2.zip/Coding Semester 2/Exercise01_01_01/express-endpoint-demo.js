//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: express-endpoint-demo.js
var express = require('express');//The global Object require is used to call in express
var app = express(); 
var fs = require('fs'); //The global Object require is used to work with the File system
var port = 8080;// port var decleration

app.use('/message', function(req, res){// callback function with request and respnse parameters
    console.log('User requested an endpoint!');// console.log message
    res.send('<h2>A response from the server!</h2>');//sends a respnse to the broweser from the server
});

app.use('/users', function(req, res){// callback function with request and respnse parameters
    fs.readFile('./data.json', 'utf-8', function(err, data){//reads file data.json and outputs content from the file
        res.send(data);
    });

});


app.listen(port, function(){
    console.log('server is listening on localhost:%s', port)//console.log that says the port
});