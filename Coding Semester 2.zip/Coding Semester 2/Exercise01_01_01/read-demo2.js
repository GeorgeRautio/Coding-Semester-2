//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: read-demo2.js

 var data = require('./data.json');//The global Object require is used to go to the data.json file in the current dir

console.log(data.name); //console.log displays the name in the data.json
