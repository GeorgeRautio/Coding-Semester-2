//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: my-Modules.js

// this is the module for module-demo

exports.myText = 'Hello from myModule!';