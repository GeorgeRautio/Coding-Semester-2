//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: write-file-demo.js


var fs = require('fs');//The global Object require is used to work with the File system

var jsonString = {// looks like json but is only a text string
    name: "George"
};

fs.writeFile('./data2.json', JSON.stringify(jsonString), function(err){//writes to the file data2.json the fake json string in a call back function form
    if (err) {
       console.log('Error: ', err); //console.log displays the error
       }
});