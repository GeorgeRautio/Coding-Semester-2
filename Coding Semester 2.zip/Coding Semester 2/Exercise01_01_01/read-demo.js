//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: read-demo.js

 var fs = require('fs');// declars gets core modual file system

fs.readFile('./data.json','utf-8', function (err, data){//reads file data.json with callback function
    console.log(data);
    data = JSON.parse(data);
    console.log(data.name);
});