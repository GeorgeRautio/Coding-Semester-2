//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: Module-demo.js

var myModule = require('./my-Modules');//The global Object require is used to go to the modules folder

console.log('Text from the externl module: ', myModule.myText);//console.log that the text from the external module 