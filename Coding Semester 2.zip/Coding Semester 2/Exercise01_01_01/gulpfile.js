//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: gulpfile.js

var gulp = require('gulp');// var decleration for gulp

gulp.task('default', function() {
    
    console.log('Hello from gulp!');
    
});// defining the tasks that gulp is gunna preform with a call back function


