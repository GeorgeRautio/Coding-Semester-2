
//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: async-demo.js





var fs = require('fs');// var decleration for file system

function phoneNumber(err, data) {//callback functtion named phonenumber
    console.log('data: ', data); //displays the data

}
fs.readdir('.', phoneNumber);//reads the current directory
console.log('This is the last code');//prints this is  the last code in the terminal
