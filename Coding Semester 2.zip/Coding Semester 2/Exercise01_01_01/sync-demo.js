//      Exercise01_01_01
//
//      Author: George Rautio
//
//      Filename: sync-demo.js




var fs = require('fs');// var decleration for file system

var data = fs.readdirSync('.');// var decleration for data and reads current directory

console.log('data: ', data);//displays the data

console.log('This is the last code');//prints this is  the last code in the terminal
