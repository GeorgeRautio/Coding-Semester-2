//BY:George Rautio
//FILE NAME:index.js
//ABOUT: server setup , and things needed to find and get into twitter
//DATE CREATED:January 23, 2018


var url = require('url');
var express = require('express');
var authenticator = require('./authenticator')
var config = require('./config.json');
var app = express();


app.use(require('cookie-parser')());//For later use to store cookies and data


app.get('/auth/twitter', authenticator.redirectToTwitterLogginPage);// the route is used to get a request token then if it is successful then it will redirect to the login/authorize the app page


app.get(url.parse(config.oauth_callback).path, function(req, res){
    
    authenticator.authenticate(req, res, function(err){
        if (err) {
           console.log(err); 
            res.sendStatus(401);
        }
        else{
            res.send('authentication successful!');
        }
    });
});

app.listen(config.port, function(){
//debug code to see what port the server is being run on and some callback info
    console.log('Server listening on localhost:%s', config.port)
    console.log('OAuth callback hostname: ' + url.parse(config.oauth_callback).hostname);
    console.log('OAuth callback path: '+ url.parse(config.oauth_callback).path);
});