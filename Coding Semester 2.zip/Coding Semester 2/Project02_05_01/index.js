//BY:George Rautio
//FILE NAME:index.js
//DATE CREATED:January 23, 2018
//ABOUT: server setup, and things needed to find and get into twitter and access its information



var url = require('url');
var express = require('express');
var bodyParser = require('body-parser')
var authenticator = require('./authenticator')
var storage = require('./storage.js');
var config = require('./config.json');
var app = express();
var querystring = require('querystring');
var async = require('async');
var MongoClient = require('mongodb').MongoClient;

storage.connect();

app.set('view engine', 'ejs');

setInterval(function(){// timer for cache to be deleted
 if(storage.connected()){
    console.log('Clearing MongoDB cache');
    storage.deleteFriends(); 
}}, 1000 * 60 * 5);

app.use(require('cookie-parser')());//For later use to store cookies and data

app.use(bodyParser.json());

app.get('/auth/twitter', authenticator.redirectToTwitterLogginPage);// the route is used to get a request token then if it is successful then it will redirect to the login/authorize the app page


app.get(url.parse(config.oauth_callback).path, function(req, res){
    
    authenticator.authenticate(req, res, function(err){
        if (err) {
   
            res.redirect("/login");
        }
        else{
            res.redirect('/');
        }
    });
});

app.get('/tweet', function(req, res){
    //this looks for if the user is authenticated and all the credentials  are there if they are not  it will say unothorized
    var credentials = authenticator.getCredential();
    if(!credentials.access_token || !credentials.access_token_secret){
        res.sendStatus(401);
    }
    //Using one of twitters apis statuses it will send a tweet
    var url = "https://api.twitter.com/1.1/statuses/update.json"; 
    authenticator.post(url, credentials.access_token, credentials.access_token_secret, 
    {
    status: "Hello, This is my first Tweet"   
    },
    function(error, data){
        if(error){
            return res.status(400).send(error);
        }
        res.send('Tweet successful!');
    });
    
});


app.get('/searchResults.ejs', function(req, res){
    var credentials = authenticator.getCredential();
    if(!credentials.access_token || !credentials.access_token_secret){
        res.sendStatus(401);
    }

    var url = "https://api.twitter.com/1.1/search/tweets.json";
    var query = querystring.stringify({q: "" });
    url += "?" + query;
    authenticator.get(url, credentials.access_token, credentials.access_token_secret, function(error, data){
     
        if(error){
         return res.status(400).send(error);
     }   
    res.send(data);
    });
});


// endpoint that resquest to a command for serever to reapond to
app.get('/search', function(req, res){
    var credentials = authenticator.getCredential();
    if(!credentials.access_token || !credentials.access_token_secret){
        res.sendStatus(401);
    }
    //Using one of twitters apis search it will search for the json string Call of Duty and return all the most recent tweets or an 400 status code as an error 
    var url = "https://api.twitter.com/1.1/search/tweets.json";
    var query = querystring.stringify({q: "Call of Duty" });
    url += "?" + query;
    authenticator.get(url, credentials.access_token, credentials.access_token_secret, function(error, data){
     
        if(error){
         return res.status(400).send(error);
     }   
    res.send(data);
    });
});
//this looks for if the user is authenticated and all the credentials  are there if they are not  it will say unothorized 401
app.get('/friends', function(req, res){
    var credentials = authenticator.getCredential();
    if(!credentials.access_token || !credentials.access_token_secret){
        res.sendStatus(401);
    }
    //Using one of twitters apis friends it will give the friends cursors at the end and we put the cur 
    var url = "https://api.twitter.com/1.1/friends/list.json";
    if (req.query.cursor){
        url += "?" + querystring.stringify({ cursor: req.query.cursor });
    }
    authenticator.get(url, credentials.access_token, credentials.access_token_secret, function(error, data){
     
        if(error){
         return res.status(400).send(error);
     }   
    res.send(data);
    });
});



// loads friends from mongodb if nothing in there then it will go to twitter for the friends info
app.get('/', function(req, res){
    var credentials = authenticator.getCredential();
    if(!credentials.access_token || !credentials.access_token_secret){
        res.redirect('/login');
    }
   if(!storage.connected){
        console.log('Loading friends from Twitter');
        return renderMainPageFromTwitter(req, res);
   }
    console.log("Loading friends form MongoDB");
    storage.getFriends(credentials.twitter_id, function(err,friends){
        if (err){
            return res.send(500).send(err);
        }
        if( friends.length > 0){
            console.log('Friends successfully loaded from MongoDB');
        friends.sort(function(a, b){
            return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
        });
             res.render('index', { friends: friends });
        }
        else {
            console.log('Loading friends from Twitter');
            renderMainPageFromTwitter(req, res);
        
        }
    });
});

app.get('/login', function(req, res){
   authenticator.clearCredentials();
    if(storage.connected()){// deletes cache on login
        console.log('Deleting friends collection on login');
        storage.deleteFriends();
    }

    res.render("login");
});

function renderMainPageFromTwitter (req, res){
     var credentials = authenticator.getCredential();
      async.waterfall ([
          
        //task 1 get friends ids  and puts in an array can puts the cursor at the top of the array 
        function(callback){
            var cursor = -1;
            var ids = [];
            async.whilst(function(){//1 control number of loops
                return cursor != 0;
            } ,
                function(callback){//2 dose all the work gets all the ids
                var url = "https://api.twitter.com/1.1/friends/ids.json";
                url += "?" + querystring.stringify({
                   user_id: credentials.twitter_id, cursor: cursor 
                });
                authenticator.get(url,credentials.access_token, credentials.access_token_secret, 
                function(err, data){
                    if(err){
                        return res.status(400).send(err);
                    }
                    data = JSON.parse(data);
                    cursor = data.next_cursor_str;
                    ids = ids.concat(data.ids);
                    callback();
                });
            },function(err){//3 call back/loop end
                if (err) {
                    return res.status(500).send(err);
                }
                callback(null, ids);
            });
        },
        //task 2 look up friends data/ids
        function(ids, callback){
            var getHundredIDs = function(i){// retuns the next 100 ids in the ids array
                return ids.slice(100*i, Math.min(ids.length,100*(i+1)));
            }
            var requestsNeeded = Math.ceil(ids.length/100);//if uneven number of ids it will round up
            async.times(requestsNeeded,function(n, next){
            var url = "https://api.twitter.com/1.1/users/lookup.json";
                url += "?" + querystring.stringify({
                    user_id: getHundredIDs(n).join(',')
                });
                authenticator.get(url,credentials.access_token, credentials.access_token_secret, function(error,data){
                    if(error){
                         return res.status(400).send(error);
                    }
                    var friends = JSON.parse(data);
                    next(null, friends);
                });
                
            }, function(error, friends){
                //cleans data
                friends = friends.reduce(function( previousValue, currentValue, currentIndex, array){
                    return previousValue.concat(currentValue)
                }, []);
                //alphabetiz the data
                friends.sort(function(a, b){
                    return a.name.toLowerCase().localeCompare(b.name.toLowerCase())
                });
                friends = friends.map(function(friend){
                    return {
                        twitter_id: friend.id_str,
                        for_user: credentials.twitter_id,
                        name: friend.name,
                        screen_name: friend.screen_name,
                        location: friend.location,
                        profile_image_url: friend.profile_image_url,
                        description: friend.description
            
                        
                    }
                });
                res.render("index", { friends: friends 
                                    
                });
                if (storage.connected()){
                storage.insertFriends(friends);
            }
            });
        }
    ]);

}


app.get('/logout', function(req, res){
   authenticator.clearCredentials();//clears Credentials
    res.clearCookie('twitter_id');
     if(storage.connected()){//deletes cache on logout
     console.log('Deleting friends collection on logout');
     storage.deleteFriends();
     }
   
    res.redirect("/login");
});


function ensureLoggedIn(req, res, next){//middlewear checks credentials puts twitter id into cookie
    var credentials = authenticator.getCredential();
    if(!credentials.access_token || !credentials.access_token_secret || !credentials.twitter_id){
        return res.sendStatus(401);
    }
    res.cookie('twitter_id', credentials.twitter_id, {httponly: true});
    next();
}
//app.get for the GET api
app.get('/friends/:uid/notes', ensureLoggedIn, function(req, res){
    var credentials = authenticator.getCredential();
    storage.getNotes(credentials.twitter_id, req.params.uid, function(err, notes){
        if(err){
            return res.status(500).send(err);
        }
        res.send(notes);
    });
});
//app.post for the POST api
app.post('/friends/:uid/notes', ensureLoggedIn, function(req, res){
    storage.insertNote(req.cookies.twitter_id, req.params.uid, req.body.content, function(err, note){
      if(err){
          return res.status(500).send(err);
      }  
        res.send(note);
    });
    
});
//app.put for the PUT api
app.put('/friends/:uid/notes/:noteid', ensureLoggedIn, function(req, res){
    storage.updateNote(req.params.noteid, req.cookies.twitter_id, req.body.content, 
    function(err, note){
      if(err){
          return res.status(500).send(err);
      }  
        res.send({
            _id: note._id,
            content: note.content
        });
    });
    
});
//app.delete for the DELETE api
app.delete('/friends/:uid/notes/:noteid', ensureLoggedIn, function(req, res){
    storage.deleteNote(req.params.noteid, req.cookies.twitter_id,
    function(err, note){
      if(err){
          return res.status(500).send(err);
      }  
        res.sendStatus(200);
    });
    
});

app.use(express.static(__dirname + '/public'));

app.listen(config.port, function(){
//debug code to see what port the server is being run on and some callback info
    console.log('Server listening on localhost:%s', config.port)
    console.log('OAuth callback hostname: ' + url.parse(config.oauth_callback).hostname);
    console.log('OAuth callback path: '+ url.parse(config.oauth_callback).path);
});